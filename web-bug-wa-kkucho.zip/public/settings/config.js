global.creator = "@kkk4kucho"
global.token = "8104600811:AAGkKOxzegYatOqFFQ6Lq8sr28RfTXiDRgk"
global.chatid = "7398845232"
global.watermark = "© kakuchooo"
